#All testing was done on WSL as this was primarily made for linux machines and not window maches other than running on WSL

import argparse
import os
import re
import shlex
import nmap
import subprocess
from openpyxl import Workbook
from openpyxl.styles import NamedStyle, Font, Border, Side, Alignment, PatternFill
from openpyxl.formatting import Rule
from openpyxl.styles.differential import DifferentialStyle

#Allows the script to have arguments that enable different options for the user rather than using a "Choose your own adventure" model where the user must enter in yes or no
parser = argparse.ArgumentParser()
parser.add_argument("-r" , "--run" , help="Chooses whether to run the appropriate Proof of concepts that correlates to the found vulnerability.", action="store_true")
parser.add_argument("-v" , "--verbose" , help="Increases the verbosity while running the scan." , action="store_true")
parser.add_argument("--Version" , help="Displays what version the tool is currently at." , action="store_true")
parser.add_argument("ipAddr" , nargs="*" , help="Input the individual IP address(es) to be scanned OR put a file with a list of IP addresses that is delimited by new lines. (subnet masks co not work in current iteration!)")
parser.add_argument("-of" , "--output" , help="determines whether the results are neatly formatted to a excel document for later use." , action="store_true") 
args = parser.parse_args()


# Set the pattern fill for the conditional formatting
fillColor = PatternFill(start_color="FFD9D9D9", end_color="FFD9D9D9", fill_type="solid")
fillColor.font =Font(color="FF005496")

#uses regex to validate that it is an ip address if it is not a file
def ValidIPAddress(ipAddress):
    pattern = re.compile(r'^(\d{1,3}\.){3}\d{1,3}$')
    return pattern.match(ipAddress) is not None


#does a check to validate if it is a file or if it is a set of ip addresses (only needs to look at first location in list to confirm what it is)
if os.path.isfile(args.ipAddr[0]):
    ipAddr = []
    with open(args.ipAddr[0], 'r') as IPADDRS:
        for line in IPADDRS:
           ipAddr.append(line.strip())
elif ValidIPAddress(args.ipAddr[0]) != 0:
    ipAddr = args.ipAddr
    
          
version = args.Version
run = args.run
fileOutput = args.output

#~~~~~~~~~~~~~~~~~~~~~~~~ARGUMENTS ABOVE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


#CIDRRegex = "^([0-9]{1,3}\.){3}[0-9]{1,3}(\/([0-9]|[1-2][0-9]|3[0-1]))$"
nm = nmap.PortScanner()

#shows the user the version of the program
if args.Version:
    print("ADWC is on version 1.0")

def scanForWebPorts():
    scanResults = {}
    portCheck = {}
    ports = [80, 443, 8080, 8443]
   
    for i in ipAddr:
        #Creates a dictionary that holds port status of each ip address using dictionary comprehension to transfer from one dictionary to another 
        portCheck = {i: {f"port{port}": False for port in ports} for i in ipAddr}
        if args.verbose:
            print("Starting Scan of Ip Address: " + i)


        #Initiates the Nmap scan for each ip address, currently does not work with CIDR notation
        scanResults[i] = nm.scan(i, ','.join(str(port) for port in ports))
       
       
        try:
            #if the ip address is down or it it has been misstyped then  it will be removed from the list of ip addresses
            if scanResults[i]['scan'][i]['status']['state'] == "down":
                print("This IP Address appears to be down!")
                ipAddr.remove(i)
                del scanResults[i]
                del portCheck[i]
                continue
        except:
            print(i + " does not exist or was misstyped")
            ipAddr.remove(i)
            del scanResults[i]
            del portCheck[i]
            continue
        
        #Checks the different default web ports and confirms their state
        for port in ports:
            if scanResults[i]['scan'][i]['tcp'][port]["state"] == "open":
                portCheck[i][f"port{port}"] = True
                if args.verbose:
                    print(f"Port {port} is open!")   
            else:
                if args.verbose:
                    print(f"Port {port} is closed!")
            #if all the port states are closed then it is removed from the list as well

        if all(not portCheck[i][f"port{port}"] for port in ports):
            ipAddr.remove(i)
            del scanResults[i]
            del portCheck[i]
        print("IP address " + i + " finished!")
            
            
    return scanResults,portCheck
    


def findVulns():
    cleanNiktoResults = {}
    cleanDirbResults = {}
    cleanWapResults = {}
    for i in ipAddr:
        '''Runs the three different types of scans that are being used for vulnerability scanning: Nikto (which is being used for vuln scanning), Dirb (Being used to look for directories that shouldn't be seen), and Wapiti (Being used for more advanced vuln scanning)
        Saves all of these to dictionaries which are going to be written to txt files in a later function so they can be deleted and all read from the txt file instead. Also gives the user the raw output for the files so they can look for any missed vulns themselves as well'''
        print("Starting Nikto scan for " + i)
        NiktoResults =  subprocess.check_output(["nikto", "-h", i, "-p", "80, 443, 8080, 8443"])
        cleanNiktoResults[i] = str(NiktoResults, "UTF-8")
        if args.verbose:
            print(cleanNiktoResults[i])
        print("Starting Dirbuster scan for " + i)
        DirbResults =  subprocess.check_output(["dirb", "http://" + i + "/", "-N", "302", "403", "-S"])
        cleanDirbResults[i] = str(DirbResults, "UTF-8")
        if args.verbose:
            print(cleanDirbResults[i])
            
        print("Starting Wapiti scan for " + i)
        WapResults = subprocess.check_output(["wapiti", "-u", "http://" + i + "/", "-f", "txt", "-o", "./WapitiRes" + i + ".txt", "-m", "all", "--max-scan-time", "180","--max-attack-time", "180", "--color", "--scope", "folder", "--flush-session"])
        cleanWapResults[i] = str(WapResults, "UTF-8")
        if args.verbose:
            print (cleanWapResults[i])
    
    return cleanNiktoResults,cleanDirbResults

def filteringVulns():

    #PoC and VulnsWap should line up perfectly 
    selectVulnsNik = {}
    selectDirsDirb = {}
    selectVulnsWap = {}
    selectPoCWap = {}

    #List of identifiers for finding specific vulnerabilities within a web application

    listOfVulnsNik = [".*admin.*", "outdated", "anti-clickjacking", "cgi-bin.*found",".*robots.txt.*", "Cookie" ]
    listOfDirsDirb = [r"\S*admin\S*", r"\S*robots.txt\S*", r"\S*passwd\S*", r"\S*cgi-bin\S*"]
    listOfVulnsWap = [r".*Credentials found for.*", r".*CSP is not set.*", r".*Lack of anti CSRF token.*", r".*X-Frame-Options is not set.*", r".*X-XSS-Protection is not set.*", r".*X-Content-Type-Options is not set.*", r".*Strict-Transport-Security is not set.*", r".*HttpOnly flag is not set in the cookie.*", r".*Open Redirect via injection in the parameter redirect.*", r".*Secure flag is not set in the cookie.*", r".*XSS vulnerability found via injection in the parameter.*", r".*SQL Injection (DMBS: MySQL) via injection in the parameter.*" ]
    PoCWap = r".*PoC.*"

    for i in ipAddr:
        selectVulnsNik[i] = {} 
        selectDirsDirb[i] = {} 
        selectVulnsWap[i] = {} 
        selectPoCWap[i] = {}
        with open("RawNik" + i + ".txt", "r") as NikFile:
            counter = 0
            for line in NikFile:
                for match in listOfVulnsNik:
                    if re.search(match, line, re.IGNORECASE):
                        selectVulnsNik[i]["vuln" + str(counter)] = line
                        counter +=1

        with open("RawDirb" + i + ".txt", "r") as DirbFile:
            counter = 0
            for line in DirbFile:
                for match in listOfDirsDirb:
                    if re.search(match, line, re.IGNORECASE):
                         selectDirsDirb[i]["vuln" + str(counter)] = re.findall(match, line, re.IGNORECASE)
                         counter +=1
            

        with open("WapitiRes" + i + ".txt", "r") as WapFile:
            counter1 = 0
            counter2 = 0
            for line in WapFile:
                for match in listOfVulnsWap:
                    if re.search(match, line, re.IGNORECASE):
                        selectVulnsWap[i]["vuln" + str(counter1)] = line
                        counter1 +=1
                if re.search(PoCWap, line, re.IGNORECASE):
                    selectPoCWap[i]["vuln" + str(counter2)] = line
                    counter2 +=1
            
        

    return selectVulnsNik, selectDirsDirb, selectVulnsWap, selectPoCWap
 

def runExploit(selectPoCWap):
    ExpResults = {}

    #RegEx variable that is used to extract the curl command
    curlGrab = [r'"([^"]+)"(?:\s([^"]+))*"([^"]+)"(?:\s([^"]+))*"([^"]+)"', r'curl\s"([^"]+)"']

    for i in ipAddr:
        counter=0
        ExpResults[i] = {}
        for index ,result in enumerate(selectPoCWap[i]):
            print(selectPoCWap[i][result])
            for args in curlGrab:
                if re.search(args, selectPoCWap[i][result]):
                    uncleanedResults = re.findall(args, selectPoCWap[i][result])
                    uncleanedResultsList = list(uncleanedResults)
                    for search in uncleanedResultsList: 
                        if isinstance(search, tuple):
                            for item in search:
                                item = str(item)
                                item = item.strip()
                                item = '"' + item + '"'
                                if re.search("http", item):
                                    ExpResults[i]["vuln" + str(counter)] = subprocess.check_output(["curl"] + shlex.split(item))
                                    counter +=1
                        else:
                            search = str(search)
                            search = search.strip()
                            ExpResults[i]["vuln" + str(counter)] = subprocess.check_output(["curl"] + shlex.split(search))
                            counter += 1
                            
    return ExpResults


def createSpreadSheet(selectVulnsNik, selectDirsDirb, selectVulnsWap, selectPoCWap, ExpRes, portCheck):
    if args.verbose:
        print("Now creating Excel sheet with all collected data")
    wb = Workbook()
    ports = ["port80", "port443", "port8080", "port8443"]
    #Creates the excel workbook and creates the help sheet, which is used to give information regarding the script once it has been ran and what information has been used to train the script's vuln recognition then a sheet for each ip address
    sourceSheet = wb.active
    sourceSheet.title = "Help"
    sourceSheet["A1"] = "Information"
    sourceSheet["A1"].style = "Headline 1"
    sourceSheet["A2"] = "This sheet is for information regarding the output of this tool and how it works for any user who is interested!"
    sourceSheet["A2"].style = "Headline 2"
    sourceSheet["A4"] = "This script is made purely for web testing and does not work unless there is a web port open on one of the default ports"
    sourceSheet["A4"].style = "Explanatory Text"
    sourceSheet["A5"] = "The script runs Nikto, Dirb, and Wapiti and checks the data that is gathered from those tools, next it filters security issues found and then attempts to exploit if the flag for exploiting is added to input. "
    sourceSheet["A5"].style = "Explanatory Text"
    sourceSheet["A6"] = "(however it deals with common exploits so uncommon exploits may not be picked up by the tool but can be seen within the raw output txt file)"
    sourceSheet["A6"].style = "Explanatory Text"
    sourceSheet["A7"] = "(the filtered out vulns were gathered using the broken OWASP machines from CMP319)"
    sourceSheet["A7"].style = "Explanatory Text"
    sourceSheet["A8"] = "the results can be found within the sheets that are named after each found ip address"
    sourceSheet["A8"].style = "Explanatory Text"
    sourceSheet["A10"] = "KEY"
    sourceSheet["A10"].style = "Headline 1"
    sourceSheet["A11"] = "Outdated Software"
    sourceSheet["A11"].style = "60 % - Accent1"
    
    for i in ipAddr:

        sheet = wb.create_sheet(i)

        sheet["A1"] = "What Ports are open?"
        sheet["A1"].style = "Headline 1"
        sheet["B1"] = "True/False"
        sheet["B1"].style = "Headline 2"
        sheet["A2"] = "Port 80"
        sheet["A2"].style = "Output"
        sheet["A3"] = "Port 443"
        sheet["A3"].style = "Output"
        sheet["A4"] = "Port 8080"
        sheet["A4"].style = "Output"
        sheet["A5"] = "Port 8443"
        sheet["A5"].style = "Output"

        counter = 2
        for index in ports:
            sheet.cell(row=counter, column=2, value=portCheck[i][index])
            counter +=1

        sheet["A9"] = "Nikto Results"
        sheet["A9"].style = "Headline 1"
        sheet["C9"] = "Dirb Results"
        sheet["C9"].style = "Headline 1"
        sheet["E9"] = "Wapiti Results"
        sheet["E9"].style = "Headline 1"


        sheet["B9"].style = "Headline 2"
        sheet["D9"].style = "Headline 2"
        sheet["F9"].style = "Headline 2"

        sheet["F9"] = "Proof of Concept (Wapiti)"

        sheet["G9"] = "Results from PoC"
        sheet["G9"].style = "Headline 3"

        #Printing Nikto Results
        for index, result in enumerate(selectVulnsNik[i]):
            cellValue = str(selectVulnsNik[i][result])
            sheet.cell(row=index + 10, column=1, value=cellValue)
            if re.search(r'\boutdated\b', cellValue):
                sheet.cell(row=index + 10, column=1, value=cellValue).fill = fillColor
            else:
                sheet.cell(row=index + 10, column=1, value=cellValue)
        #Printing Dirb Results
        for index, result in enumerate(selectDirsDirb[i]):
            sheet.cell(row=index + 10, column=3, value=str(selectDirsDirb[i][result]))

        #printing Wapiti Results
        for index, result in enumerate(selectVulnsWap[i]):
            sheet.cell(row=index + 10, column=5, value=str(selectVulnsWap[i][result]))
        for index, result in enumerate(selectPoCWap[i]):
            sheet.cell(row=index + 10, column=6, value=str(selectPoCWap[i][result]))
        if args.run:
            for index, result in enumerate(ExpRes[i]):    
                sheet.cell(row=index + 10, column=7, value=str(ExpRes[i][result]))
            
    wb.save(filename="finalResults.xlsx")


def createRawFiles(rawNikRes, rawDirbRes, rawScanRes):

    #Creates the raw output txt files so the user can read through the scans themselves
    for i in ipAddr:
        print("creating txt files for raw output of " + i)
        with open("RawNik" + i + ".txt", 'w') as Nik:
            Nik.write(rawNikRes[i])

        with open("RawDirb" + i + ".txt", 'w') as Dirb:
            Dirb.write(rawDirbRes[i])

        with open("RawNmap" + i + ".txt", 'w') as file:
            file.write(str(rawScanRes[i]))


#~~~~~~~~~~~~~~~~~~~~~~~~FUNCTIONS ABOVE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~MAIN BELOW~~~~~~~~~~~~~~~~~~~~~~~~~~~


scanRes,portCheck = scanForWebPorts()

cleanNikRes,cleanDirbRes = findVulns()

createRawFiles(cleanNikRes, cleanDirbRes, scanRes)
del cleanNikRes, cleanDirbRes

selectVulnsNik, selectDirsDirb, selectVulnsWap, selectPoCWap = filteringVulns()

if args.run:
    ExpRes = runExploit(selectPoCWap)
else:
    ExpRes = {}
if args.output:
    createSpreadSheet(selectVulnsNik, selectDirsDirb, selectVulnsWap, selectPoCWap, ExpRes, portCheck)
    